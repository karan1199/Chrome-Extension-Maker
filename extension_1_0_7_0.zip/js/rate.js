var homepage = function () {return chrome.runtime.getManifest().homepage_url};
document.querySelector('.teaser').href = `https://chrome.google.com/webstore/detail/${chrome.runtime.id}/reviews`;
document.querySelector('#toolbar-help').href = `${homepage()}toolbar-help`;